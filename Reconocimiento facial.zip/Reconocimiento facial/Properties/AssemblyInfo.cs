﻿using System.Reflection;
using System.Runtime.CompilerServices;
using System.Runtime.InteropServices;
                                            /*codigo WareCh&p*/


/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyTitle("PictureFace")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyDescription("")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyConfiguration("")]
/*informacion acerca de autoria, con licecia WareCh&p*/
[assembly: AssemblyCompany("WareCh&p")]
/*informacion acerca de autoria, con licecia WareCh&p*/
[assembly: AssemblyProduct("PictureFace")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyCopyright("Copyright  9/27/2020")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyTrademark("")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyCulture("")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: ComVisible(true)]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: Guid("00092986-4123-1151-be11-0e2f5b7c874c")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyVersion("2.0.3.0")]
/*informacion acerca de autoria, con licecia WareCh&p Open Source*/
[assembly: AssemblyFileVersion("2.0.3.0")]
