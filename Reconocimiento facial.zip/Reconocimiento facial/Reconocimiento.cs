﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.IO;
using Emgu.CV;
using Emgu.CV.Structure;
using Emgu.CV.CvEnum;
using System.Data.OleDb;
using System.Speech.Synthesis;
using System.Media;
using System.Runtime.InteropServices;
using System.Windows.Forms;

namespace Reconocimiento_facial
{

    public partial class Reconocimiento : Form
    {
        SoundPlayer media = new SoundPlayer();
        SpeechSynthesizer vos = new SpeechSynthesizer();
        Image<Bgr, Byte> currentFrame;
        Capture grabber;
        HaarCascade cara;
        MCvFont font = new MCvFont(FONT.CV_FONT_HERSHEY_TRIPLEX, 0.5d, 0.9d);
        Image<Gray, byte> result = null;
        Image<Gray, byte> gray = null;
        List<Image<Gray, byte>> imagesScan = new List<Image<Gray, byte>>();
        List<string> labels = new List<string>();
        List<string> labels1 = new List<string>();
        List<string> NamePersons = new List<string>();
        int ContTrain, NumLabels, t;
        string name, names = null, Labelsinfo;


        public Reconocimiento()
        {
            InitializeComponent(); 
            cara = new HaarCascade("haarcascade_frontalface_default.xml");
            try
            {
                Labelsinfo = File.ReadAllText(Application.StartupPath + "/filesFaces/contenedor.txt");
                string[] Labels = Labelsinfo.Split('%');
                NumLabels = Convert.ToInt16(Labels[0]);
                ContTrain = NumLabels;
                string LoadFaces;
                
                    for (int tf = 1; tf < NumLabels + 1; tf++)
                    {
                        LoadFaces = "face" + tf + ".bmp";
                        imagesScan.Add(new Image<Gray, byte>(Application.StartupPath + "/filesFaces/" + LoadFaces));
                        labels.Add(Labels[tf]);
                    }
            }
            catch (Exception e)
            {
                MessageBox.Show(e + "No hay ningun rosto registrado).", "Cargar rostros", MessageBoxButtons.OK, MessageBoxIcon.Exclamation);
            }
        }
        private void Reconocer()
        {
            grabber = new Capture();
            grabber.QueryFrame();
            Application.Idle += new EventHandler(FrameGrabber); 
        }
        private void FrameGrabber(object sender, EventArgs e)
        {
            lblNumeroDetect.Text = "0";            
            NamePersons.Add("");
            try
            {
                currentFrame = grabber.QueryFrame().Resize(640, 480, INTER.CV_INTER_CUBIC);
            }
            catch (Exception)
            {
                lblNadie.Text = "";
                imageBoxFrameGrabber.Image = null;
            }
            gray = currentFrame.Convert<Gray, Byte>();
            MCvAvgComp[][] facesDetected = gray.DetectHaarCascade(cara, 1.2, 10, HAAR_DETECTION_TYPE.FIND_BIGGEST_OBJECT, new Size(20, 20));
            foreach (MCvAvgComp f in facesDetected[0])
            {
                t = t + 1;
                result = currentFrame.Copy(f.rect).Convert<Gray, byte>().Resize(173, 168, INTER.CV_INTER_CUBIC);
                currentFrame.Draw(f.rect, new Bgr(Color.LightGreen), 1);

                if (imagesScan.ToArray().Length != 0)
                { 
                    MCvTermCriteria termCrit = new MCvTermCriteria(ContTrain, 0.001);
                    EigenObjectRecognizer recognizer = new EigenObjectRecognizer(imagesScan.ToArray(), labels.ToArray(), ref termCrit);
                    var fa = new Image<Gray, byte>[imagesScan.Count]; 
                    
                    name = recognizer.Recognize(result);
                    currentFrame.Draw(name, ref font, new Point(f.rect.X - 2, f.rect.Y - 2), new Bgr(Color.YellowGreen));                   
                }

                NamePersons[t - 1] = name;
                lblNumeroDetect.Text = facesDetected[0].Length.ToString();
                lblNadie.Text = name;

            }
            t = 0;
            for (int nnn = 0; nnn < facesDetected[0].Length; nnn++)
            {
                names = names + NamePersons[nnn] +", ";
            }
            imageBoxFrameGrabber.Image = currentFrame;      
            NamePersons.Clear();
        }

      
        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void Reconocimiento_Load(object sender, EventArgs e)
        {
            pictureBox6.ImageLocation = "filesFaces/face1.bmp";
            pictureBox6.Visible = true;

            pictureBox9.ImageLocation = "filesFaces/face2.bmp";
            pictureBox9.Visible = true;

            pictureBox11.ImageLocation = "filesFaces/face3.bmp";
            pictureBox11.Visible = true;

            pictureBox10.ImageLocation = "filesFaces/face4.bmp";
            pictureBox10.Visible = true;

            pictureBox12.ImageLocation = "filesFaces/face5.bmp";
            pictureBox12.Visible = true;

            pictureBox2.Visible = false;
            Reconocer();
        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
 
            Desconectar();
            pictureBox2.Visible = true;
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            this.Close();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            this.WindowState = FormWindowState.Minimized;
        }

        private void button2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox8_MouseDown(object sender, MouseEventArgs e)
        {
            ReleaseCapture();
            SendMessage(this.Handle, 0x112, 0xf012, 0);
        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            Reconocer();
            pictureBox2.Visible = false;
        }

        private void btnEncender_Click(object sender, EventArgs e)
        {
            Reconocer();
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void imageBoxFrameGrabber_Click(object sender, EventArgs e)
        {

        }

        private void lblNumeroDetect_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {
            
        }

        private void lblNadie_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void trackBar1_Scroll(object sender, EventArgs e)
        {

        }

        private void button2_Click_1(object sender, EventArgs e)
        {
            System.Diagnostics.Process.Start(@"filesFaces");
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
           
        }

        private void pictureBox9_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox12_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox11_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox10_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox13_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox14_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_2(object sender, EventArgs e)
        {

        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            ToolTip ttEjemplo = new ToolTip();

            ttEjemplo.SetToolTip(label5, "En desarrollo por WareCh&p Computer © | Abner Irias Abjair");


        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            Desconectar();
            pictureBox2.Visible = true;
            Registrar r = new Registrar();
            r.Show();
        }

        private void Desconectar()
        {
            Application.Idle -= new EventHandler(FrameGrabber);
            grabber.Dispose();
            imageBoxFrameGrabber.ImageLocation = "img/fondocamara.png";
            lblNadie.Text = string.Empty;
            lblNumeroDetect.Text = string.Empty;

        }

        [DllImport("user32.DLL", EntryPoint = "ReleaseCapture")]
        private extern static void ReleaseCapture();
        [DllImport("user32.DLL", EntryPoint = "SendMessage")]
        private extern static void SendMessage(System.IntPtr hWnd, int wMsg, int wParam, int IParam);

    }
}
